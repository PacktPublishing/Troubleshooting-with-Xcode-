//File.swift
//XcodeTroubleshoot 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import Foundation

struct Numbers {
    
    enum NumberError: Error{
        
        case oddError(String)
        case evenError(String)
    }
    
    static func findOdd(numbers: [Int]) throws -> Int {
        
        for number in numbers{
            if number % 2 != 0{
                throw NumberError.oddError("Odd number found")
            }
        }
        
        return numbers.count
    }
}
