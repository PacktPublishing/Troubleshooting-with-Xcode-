//FourthViewController.swift
//XcodeTroubleshoot 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class FourthViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //setUpView()
    }
    
    func setUpView(){
        
        ThirdViewController().setUpView()
        print("Third VC")
    }

}
