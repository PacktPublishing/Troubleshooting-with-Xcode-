//ViewController.swift
//XcodeTroubleshoot 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //setUpView()
    }
    
    func setUpView(){
        
        print("Second VC")
        SecondViewController().setUpView()
    }

    @IBAction func showVC(_ sender: Any) {
        
        //Present view controller
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "secondvc")
        present(vc, animated: true)
    }
    
    
}




