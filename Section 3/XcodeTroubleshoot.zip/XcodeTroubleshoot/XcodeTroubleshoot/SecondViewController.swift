//SecondViewController.swift
//XcodeTroubleshoot 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        //setUpView()
    }
    
    func setUpView(){
        
        print("Fourth VC")
        FourthViewController().setUpView()
    }

}
