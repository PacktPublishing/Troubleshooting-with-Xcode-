//ViewController.swift
//XcodeTroubleshoot 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {

    var x = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        
        oddNumbers()
    }
    
    func add(){
        
        x += 3
        
        subtract()
    }
    
    func subtract(){
        
        x -= 1

        multiply()
    }
    
    func multiply(){
        
        x *= 4
        
        divide()
    }
    
    func divide(){
        
        x /= 2
        
    }
    
    func oddNumbers(){
        
        var array = [Int]()
        for i in 0..<100{
            
            if i % 2 != 0{
                array.append(i)
            }
        }

    }
    
}




