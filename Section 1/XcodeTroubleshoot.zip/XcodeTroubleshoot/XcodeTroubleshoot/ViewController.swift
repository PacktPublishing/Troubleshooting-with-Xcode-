//ViewController.swift
//XcodeTroubleshoot 
	
//Created by Dee Odus.
//Copyright Dee Odus (Appkoder.com). All Rights Reserved.

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var fruitArray = ["apple", "banana","orange", "kiwi", "pineapple", "strawberry", "pears", "grapes"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let age = 30
        var name = "Dee Odus"
        print(name)
    }
    
    func fruitContains(characters: String) -> [String]{
        
        var filteredFruits = [String]()
        
        for fruit in fruitArray{
            
            if fruit.contains(characters){
                
                filteredFruits.append(fruit)
            }
        }
        
        print(#file, #function, #line)
        
        return filteredFruits
    }


}

extension ViewController{
    
}

